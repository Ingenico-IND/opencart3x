<?php
// Heading
$_['heading_title']           = 'Reconciliation';

// Text
$_['text_custom_block']       = 'Custom Block';
$_['text_total_informations'] = 'Total informations:';