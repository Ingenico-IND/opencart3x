<?php
// Text
$_['text_title'] = '<img src="https://www.paynimo.com/CompanyDocs/company-logo-md.png" style="width:150px;height:55px;clear:right" alt="Ingenico" title="Ingenico" />';